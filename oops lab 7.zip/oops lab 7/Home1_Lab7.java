/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Address {
    int street;
    int house;
    String city;
    int code;

    Address(int s, int h, int c, String t) {
        street = s;
        house = h;
        code = c;
        city = t;
        
       
    }
    public void setStreet(int s){
        street = s;
    }
    public int getStreet(){
        return street;
    }
     public void setHouse(int h){
        house = h;
    }
    public int getHouse(){
        return house;
    }
     public void setCode(int c){
        code = c;
    }
    public int getCode(){
        return code;
    }
    
     public void setCity(String t){
        city = t;
    }
    public String getcity(){
        return city;
    }
}
    class Person{
        String Fname;
        String Lname;
        int age;
        Address adr;
        public Person(String F,String L, int A, Address adres){
            Fname = F;
            Lname = L;
            age = A;
            adr = adres;
        }
    public void setFirstname(String f){
        Fname = f;
    }
    public String getFirstname(){
        return Fname;
    }
     public void setLastname(String l){
        Lname = l;
    }
    public String getLastname(){
        return Lname;
    }
     public void setAge(int a){
        age = a;
    }
    public int getage(){
        return age;
    }
    public boolean Display(){
        System.out.println("person's name is " + Fname+Lname+" and his age is " + age);
        System.out.println("Person's address is given below ");
        System.out.println("City name "+adr.getcity());
        System.out.println( "Street number "+adr.getStreet());
        System.out.println( "House number "+adr.getHouse());
        System.out.println("City code is " + adr.getCode());
        return true;
    }
}
