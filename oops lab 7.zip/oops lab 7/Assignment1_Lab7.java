/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Pizza {
    private String size;
    private int cheesetop;
    private int peptop;
    private int hemtop;
    private double costtopping; 
    public Pizza(String s, int chees, int pep, int ham){
        size = s;
        cheesetop = chees;
        peptop = pep;
        hemtop = ham;
    }
    public void setsize(String s){
        size = s;
    }
    public String getSize(){
        return size;
    } 
    public void setcheesetop(int chees){
        cheesetop  = chees;
    }
    public int getcheesetop(){
        return cheesetop;
    } 
     public void setpeptop(int pep){
        peptop  = pep;
    }
    public int getpeptop(){
        return peptop;
    } 
     public void sethemtop(int ham){
        hemtop  = ham;
    }
    public int gethemtop(){
        return hemtop;
    } 
    public double calCost(){
        costtopping = cheesetop+peptop+hemtop;
        double cost;
        if(size=="small"){
            cost = 10+2*costtopping;
        }
        else if(size=="medium"){
            cost = 12+2*costtopping;
        }
        else{
            cost = 14+2*costtopping;
        }
        return cost;
    }
    public boolean getDiscription(){
        System.out.println("you ordered "+ getSize()+" size pizza " + " with " + cheesetop +" Cheese toppings , " + peptop + "  pepperoni toppings and with " + hemtop + "  ham toppings and your bill for this pizza is " + calCost()+"$");
        return true;
    }
}
    class Pizzaorder{
        Pizza p;
        Pizza q;
        Pizza r;
        double count = 0;
        public Pizzaorder(Pizza a, Pizza b,Pizza c){
            p = a;
            count++;
            q = b;
            count++;
            r = c;
            count++;
            System.out.println(p.getDiscription());
            System.out.println(q.getDiscription());
            System.out.println(r.getDiscription());
            
        }
         public Pizzaorder(Pizza a, Pizza b){
            p = a;
            count++;
            q = b;
            count++;
            System.out.println(p.getDiscription());
            System.out.println(q.getDiscription());
             
        }
        public Pizzaorder(Pizza a){
            q = a;
            count++;
            System.out.println(q.getDiscription());
            
        }
        public void Calctotal(){
            if(count==3){
            System.out.println("your total bill is "+(p.calCost()+q.calCost()+r.calCost())+"$");
            }
             else if(count == 2){
            System.out.println("your total bill is "+(p.calCost()+q.calCost())+"$");
            }
            else{
            System.out.println("your total bill is "+q.calCost()+"$");
            }
            
    }
}
