/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Runner_H3_lab7 {
    public static void main(String[]args){
        Line L1 = new Line(3,5,6,7);
        Line L2 = new Line(2,8,5,9);
        Point L3 = new Point(L1,L2);
        L3.Display();
        
    }
    
}
